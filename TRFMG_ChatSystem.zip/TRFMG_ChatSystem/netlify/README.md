# TRFMG Chat Dashboard
1. Deploy index.html on Netlify for live portal
2. Import notion/*.html + CSVs into Notion
3. Use Drive structure for storage
4. Use templates for capture + weekly sweep

# Title
**Date:** YYYY-MM-DD  
**Workspace:** (e.g., MASSAGE_SEO)  
**Tags:** [AREA], [WORK TYPE], [PRIORITY]

## Summary
Two punchy sentences explaining what this is.

## Decisions
- …

## Action Items
- [ ] Owner — action (Due: YYYY-MM-DD)

## Links
- Source chat:
- Drive file(s):
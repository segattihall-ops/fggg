# Weekly Sweep Checklist
1. Open My Chats Log → filter Status=INBOX
2. Assign Next Action, Owner, Due
3. Move files from 00_Inbox → proper folders
4. Close all P1 items first